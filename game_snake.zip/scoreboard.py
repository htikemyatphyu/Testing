from turtle import Turtle


class Scoreboard(Turtle):
    def __init__(self) -> None:
        super().__init__()
        self.score = 0
        with open("Level 3\Day-5\data.txt") as data_file:
            self.highscore = int(data_file.read())
        self.goto(0, 260)
        self.color("white")
        self.hideturtle()
        self.updateScore()

    def increaseScore(self):
        self.score += 1
        self.updateScore()

    def updateScore(self):
        self.clear()
        self.goto(0, 270)
        self.write(f"Score : {self.score} Highscore: {self.highscore}",
                   align="center", font=("Roboto", 20, "bold"))

    def gameover(self,second):
        self.penup()
        self.clear()
        self.goto(0, 0)
        self.write(f"Game Over. Restarting in {second}", align="center", font=("Roboto", 40, "bold"))

    
    def reset(self):
        if self.score > self.highscore:
            self.highscore = self.score
            with open("Level 3\Day-5\data.txt", "w") as data_file:
                data_file.write(str(self.highscore))
        self.score = 0
        self.updateScore()
