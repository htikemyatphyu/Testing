class Animal:

    def __init__(self) -> None:
        pass

    def eat(self):
        print("I am eating something")
    
    def walk(self):
        print("I am walking somewhere")


# Dog class posses methods within Animal
class Dog(Animal):

    def __init__(self) -> None:
        super().__init__()
    
    def bark(self):
        print("The dog is barking")

    def eat(self):
        super().walk()
        print("Breakfast")

bophyu = Dog()
bophyu.eat()

animal = Animal()
animal.eat()

