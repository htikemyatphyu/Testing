from turtle import Turtle

POSITIONS = [(0, 0), (-20, 0), (-40, 0)]


class Snake:
    def __init__(self) -> None:
        self.segments = []
        self.createSnake()
        self.head = self.segments[0]

    def createSnake(self):
        for position in POSITIONS:
            self.addSegment(position)

    def addSegment(self, position):
        new_segement = Turtle("square")
        new_segement.color("white")
        new_segement.penup()
        new_segement.goto(position)
        self.segments.append(new_segement)

    def extend(self):
        self.addSegment(self.segments[-1].position())

    def moveSnake(self):
        for i in range(len(self.segments)-1, 0, -1):
            new_position = self.segments[i-1].position()
            self.segments[i].goto(new_position)

        self.segments[0].forward(20)

    def up(self):
        if self.head.heading() != 270:
            self.head.setheading(90)  # North

    def down(self):
        if self.head.heading() != 90:
            self.head.setheading(270)  # South

    def left(self):
        if self.head.heading() != 0:
            self.head.setheading(180)  # Left

    def right(self):
        if self.head.heading() != 180:
            self.head.setheading(0)  # Right

    def reset(self):
        for segement in self.segments:
            segement.hideturtle()
        self.segments = []
        self.createSnake()
        self.head = self.segments[0]
